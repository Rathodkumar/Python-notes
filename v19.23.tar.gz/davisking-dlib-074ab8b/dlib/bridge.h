// Copyright (C) 2011  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.

#ifdef DLIB_ALL_SOURCE_END
#include "dlib_basic_cpp_build_tutorial.txt"
#endif


#ifndef DLIB_BRIdGE_
#define DLIB_BRIdGE_ 


#include "bridge/bridge.h"

#endif // DLIB_BRIdGE_ 


