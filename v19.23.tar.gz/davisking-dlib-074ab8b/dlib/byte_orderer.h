// Copyright (C) 2006  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_BYTE_ORDEREr_ 
#define DLIB_BYTE_ORDEREr_ 


#include "byte_orderer/byte_orderer_kernel_1.h"

#endif // DLIB_BYTE_ORDEREr_ 

